// JavaScript Document
 $('#myCarousel').carousel({
    interval: 10000,
 })


	